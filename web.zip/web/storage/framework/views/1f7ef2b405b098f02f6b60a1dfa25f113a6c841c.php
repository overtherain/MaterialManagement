<!DOCTYPE html>
<html lang="<?php echo e(config('app.locale')); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Styles -->
    <!--<link href="/css/app.css" rel="stylesheet">-->
    <link href="//cdn.bootcss.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet" media="screen">
    <link href="/css/bootstrap-datetimepicker.min.css" rel="stylesheet">

    <!-- Scripts -->
    <script src="http://cdn.staticfile.org/jquery/1.11.3/jquery.min.js"></script>
    <script src="//cdn.bootcss.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
    <script src="/js/bootstrap-datetimepicker.js" charset="UTF-8"></script>
    <script src="/js/bootstrap-datetimepicker.zh-CN.js" charset="UTF-8"></script>
    
    <script>
        window.Laravel = <?php echo json_encode([
            'csrfToken' => csrf_token(),
        ]); ?>;
    </script>
    
</head>
<body>
    <div id="app">
        <nav class="navbar navbar-default navbar-static-top">
            <div class="container">
                <div class="navbar-header">

                    <!-- Branding Image -->
                    <a class="navbar-brand" href="<?php echo e(url('/home')); ?>">
                        <?php echo e(config('app.name', 'Laravel')); ?>

                    </a>
                </div>
                
                <div class="collapse navbar-collapse" id="app-navbar-collapse">
                    <!-- Left Side Of Navbar -->
                    <ul class="nav navbar-nav">
                        <?php if(Auth::guest()): ?>
                            &nbsp;
                        <?php elseif(Auth::user()->name == 'admin'): ?>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" 
                                            data-toggle="dropdown" 
                                            role="button" 
                                            aria-expanded="false">
                                    表项编辑
                                    <span class="caret"></span>
                                </a>
                                <ul class="dropdown-menu" role="menu">
                                    <li>
                                        <a href="<?php echo e(url('/edittable/edittable1')); ?>">编辑IC类型 </a>
                                        <a href="<?php echo e(url('/edittable/edittable2')); ?>">编辑主动电子件类型</a>
                                        <a href="<?php echo e(url('/edittable/edittable3')); ?>">编辑厂商表</a>
                                        <a href="<?php echo e(url('/edittable/edittable4')); ?>">编辑机种代码</a>
                                        <a href="<?php echo e(url('/edittable/edittable5')); ?>">编辑屏蔽罩类型</a>
                                        <a href="<?php echo e(url('/edittable/edittable6')); ?>">编辑颜色码</a>
                                        <a href="<?php echo e(url('/edittable/edittable7')); ?>">编辑客户码</a>
                                    </li>
                                </ul>
                            </li>
                            <li><a href="<?php echo e(url('/addid')); ?>">物料编号申请</a></li>
                            
                        <?php else: ?>
                            <li><a href="<?php echo e(url('/addid')); ?>">物料编号申请</a></li>
                        <?php endif; ?>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">帮助<span class="caret"></span></a>
                                <ul class="dropdown-menu" role="menu">
                                    <li>
                                        <a href="<?php echo e(url('/help/out2xls')); ?>">导出excel表单</a>
                                        <a href="<?php echo e(url('/help/rules')); ?>">编码规则</a>
                                        <a href="<?php echo e(url('/help')); ?>">帮助</a>
                                    </li>
                                </ul>
                            </li>
                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="nav navbar-nav navbar-right">
                        <!-- Authentication Links -->
                        <?php if(Auth::guest()): ?>
                            <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
                            <li><a href="<?php echo e(route('register')); ?>">Register</a></li>
                        <?php else: ?>
                            <ul class="nav navbar-nav">
                                <?php if(Auth::user()->name == 'admin'): ?>
                                    <li><a href="<?php echo e(url('/search')); ?>">查找</a></li>
                                    <li><a href="<?php echo e(url('/delete')); ?>">删除</a></li>
                                <?php else: ?>
                                    <li></li>
                                    <li><a href="<?php echo e(url('/search')); ?>">查找</a></li>
                                <?php endif; ?>
                            </ul>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                    <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                                </a>

                                <ul class="dropdown-menu" role="menu">
                                    <li>
                                        <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();document.getElementById('logout-form').submit();">
                                            Logout
                                        </a>

                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                            <?php echo e(csrf_field()); ?>

                                        </form>
                                    </li>
                                </ul>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</body>
</html>
