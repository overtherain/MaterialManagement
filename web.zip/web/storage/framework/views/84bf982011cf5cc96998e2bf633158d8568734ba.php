<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-lg-12 col-md-offset-0">
            <div class="panel panel-default">
                <div class="panel-heading">已申请物料信息</div>

                <div class="panel-body">
                    <table class="table table-hover table-striped table-bordered table-condensed" style="word-break:break-all; word-wrap:break-all;">
                        <thead>
                            <tr>
                                <th>id</th>
                                <th>Material_num</th>
                                <th>Author</th>
                                <th>Description</th>
                                <th>Notes</th>
                                <th>AddTime</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $materialitems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $materialitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td width="50"><?php echo e($materialitem->id); ?></td>
                                <td width="130"><?php echo e($materialitem->Material_num); ?></td>
                                <td width="100"><?php echo e($materialitem->Author); ?></td>
                                <td ><?php echo e($materialitem->Description); ?></td>
                                <td width="200"><?php echo e($materialitem->Notes); ?></td>
                                <td width="150"><?php echo e($materialitem->AddTime); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tbody>
                    </table>
                    <?php echo $materialitems->render(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>